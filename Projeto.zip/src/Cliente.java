public class Cliente {
    private String nome;
}
